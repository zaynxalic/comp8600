def contribution_statement():
    # TODO Add contribution / reference / collaboration statement as a string.
    statement = "My group members are Yichao Jiang and Xuecheng Zhang. Contribution: Yichao Jiang 50%, Xuecheng Zhang 50%. \n " 
    statement += "Reference: scikit-learn manual for GPR https://scikit-learn.org/stable/modules/generated/sklearn.gaussian_process.GaussianProcessRegressor.html#sklearn.gaussian_process.GaussianProcessRegressor \n"
    statement += "Yichao Jiang finished Q1 and Xuecheng Zhang finshed Q2 and we discussed the final result together."
    return statement